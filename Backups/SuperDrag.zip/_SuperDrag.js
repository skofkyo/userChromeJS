GESTURES = {
	image: {
		U: {
			//新标签打开图片(后台)（上）
			name: "新标签打开图片(后台)",
			cmd: function(event) {
				gBrowser.addTab(event.dataTransfer.getData("application/x-moz-file-promise-url"));
			}
		},
		D: {
			//下载图片（下）
			name: "下载图片",
			cmd: function(event) {
				saveImageURL(event.dataTransfer.getData("application/x-moz-file-promise-url"), null, null, null, null, null, document);
			}
		},
		L: {
			//搜索相似图片(baidu)（左）
			name: "搜索相似图片(baidu)",
			cmd: function(event) {
				gBrowser.addTab('http://stu.baidu.com/i?rt=0&rn=10&ct=1&tn=baiduimage&objurl=' + encodeURIComponent(event.dataTransfer.getData("application/x-moz-file-promise-url")));
			}
		},
		R: {
			//搜索相似图片(Google)（右）
			name: "搜索相似图片(Google)",
			cmd: function(event) {
				gBrowser.addTab('http://www.google.com/searchbyimage?image_url=' + encodeURIComponent(event.dataTransfer.getData("application/x-moz-file-promise-url")));
			}
		},
		DL: {
			//复制图片(下-左)
			name: "复制图片",
			cmd: function(event) {
				(document.popupNode = content.document.createElement('img')).src = event.dataTransfer.getData("application/x-moz-file-promise-url");
				goDoCommand('cmd_copyImageContents');
			}
		},
		DR: {
			//复制图片地址(下-右)
			name: "复制图片地址",
			cmd: function(event) {
				Components.classes['@mozilla.org/widget/clipboardhelper;1'].createInstance(Components.interfaces.nsIClipboardHelper).copyString(event.dataTransfer.getData("application/x-moz-file-promise-url"));
			}
		},
		LR: {
			//搜索相似图片(全部引擎)（左-右）
			name: "搜索相似图片(全部引擎)",
			cmd: function(event) {
				gBrowser.addTab('http://www.tineye.com/search?url=' + encodeURIComponent(event.dataTransfer.getData("application/x-moz-file-promise-url")));
				gBrowser.addTab('http://stu.baidu.com/i?rt=0&rn=10&ct=1&tn=baiduimage&objurl=' + encodeURIComponent(event.dataTransfer.getData("application/x-moz-file-promise-url")));
				gBrowser.addTab('http://www.google.co.jp/searchbyimage?image_url=' + encodeURIComponent(event.dataTransfer.getData("application/x-moz-file-promise-url")));
				gBrowser.addTab('http://pic.sogou.com/ris?query=' + encodeURIComponent(event.dataTransfer.getData("application/x-moz-file-promise-url")));
				gBrowser.addTab('http://iqdb.org/?url=' + encodeURIComponent(event.dataTransfer.getData("application/x-moz-file-promise-url")));
			}
		},
	},
	link: {
		U: {
			//新标签打开链接(后台)（上）
			name: "新标签打开链接(后台)",
			cmd: function(event) {
				gBrowser.addTab(event.dataTransfer.getData("text/x-moz-url").replace(/[\n\r]+/, "\n").split("\n")[0]);
			}
		},
		D: {
			//下载链接（下）
			name: "下载链接",
			cmd: function(event) {
				saveImageURL(event.dataTransfer.getData("text/x-moz-url").replace(/[\n\r]+/, "\n").split("\n")[0], null, null, null, null, null, document);
			}
		},
		L: {
			//baidu搜索链接文字(后台)（左）
			name: "baidu搜索链接文字(后台)",
			cmd: function(event) {
				gBrowser.addTab('https://www.baidu.com/s?wd=' + event.dataTransfer.getData("text/x-moz-url").replace(/[\n\r]+/, "\n").split("\n")[1]);
			}
		},
		R: {
			//Google搜索链接文字(后台)（右）
			name: "Google搜索链接文字(后台)",	
			cmd: function(event) {
				gBrowser.addTab('http://www.google.com/search?q=' + encodeURIComponent(event.dataTransfer.getData("text/x-moz-url").replace(/[\n\r]+/, "\n").split("\n")[1]));
			}
		},
		DL: {
			//复制链接(下-左)
			name: "复制链接",
			cmd: function(event) {
				Components.classes['@mozilla.org/widget/clipboardhelper;1'].createInstance(Components.interfaces.nsIClipboardHelper).copyString(event.dataTransfer.getData("text/x-moz-url").replace(/[\n\r]+/, "\n").split("\n")[0]);
			}
		},
		DR: {
		    //Google 翻译链接文字 (中文)(下-右)
			name: "Google 翻译链接文字 (中文)",
			cmd: function(event) {
				var div = content.document.documentElement.appendChild(content.document.createElement("div"));
				div.style.cssText = "position:absolute;z-index:1000;border:2px solid #FFF;border-radius:5px;background-color:#3B3B3B;padding: 0px 3px 1px 3px;font-size:12pt;box-shadow: 0px 0px 4px #000;color:#FFF;opacity:0.95;left:" + +(event.clientX + content.scrollX + 10) + 'px;top:' + +(event.clientY + content.scrollY + 10) + "px";
				var xmlhttp = new XMLHttpRequest;
				xmlhttp.open("get", "http://translate.google.cn/translate_a/t?client=t&hl=zh-CN&sl=auto&tl=zh-CN&text=" + event.dataTransfer.getData("text/x-moz-url").replace(/[\n\r]+/, "\n").split("\n")[1], 0);
				xmlhttp.send();
				div.textContent = eval("(" + xmlhttp.responseText + ")")[0][0][0];
				content.addEventListener("click", function(e) {
					if (e.button == 0) {
					Components.classes['@mozilla.org/widget/clipboardhelper;1'].createInstance(Components.interfaces.nsIClipboardHelper).copyString(div.textContent);
						goDoCommand("cmd_paste");
					}
					else if (e.button==2) {
					e.preventDefault();
                          }
					content.removeEventListener("click", arguments.callee, false);
					div.parentNode.removeChild(div);
				}, false);
			}
		},
		UD: {
			//复制链接文字(上-下)
			name: "复制链接文字",
			cmd: function(event) {
				Components.classes['@mozilla.org/widget/clipboardhelper;1'].createInstance(Components.interfaces.nsIClipboardHelper).copyString(event.dataTransfer.getData("text/x-moz-url").replace(/[\n\r]+/, "\n").split("\n")[1]);
			}
		},
	},
	text: {
		U: {
			//按URL打开文本(上)
			name: "按URL打开文本",
			cmd: function(event) {
				gBrowser.selectedTab = gBrowser.addTab(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,""));
			}
		},
		D: {
			//下载文字(下)
			name: "下载文字",
			cmd: function(event) {
				saveImageURL('data:text/plain;charset=UTF-8;base64,' + btoa(unescape(encodeURIComponent(event.dataTransfer.getData("text/unicode")))), event.dataTransfer.getData("text/unicode").slice(0, 5) + ".txt", null, null, null, null, document);
			}
		},
		UD: {
			//复制文本(上-下)
			name: "复制文本",
			cmd: function(event) {
				Components.classes['@mozilla.org/widget/clipboardhelper;1'].createInstance(Components.interfaces.nsIClipboardHelper).copyString(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,""));
			}
		},
/*    	L: {
    		//baidu搜索选中文字(后台)（左）
    		name: "baidu搜索选中文字(后台)",
    		cmd: function(event) {
    			gBrowser.addTab('http://www.baidu.com/s?wd=' + event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,""));
    		}
    	},
    	R: {
    		//Google搜索选中文字(后台)（右）
    		name: "Google搜索选中文字(后台)",
    		cmd: function(event) {
    			gBrowser.addTab('http://www.google.com/search?q=' + encodeURIComponent(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"")));
    		}
    	},*/
    	L: {
    		//baidu搜索选中文字(后台)[识别URL和空格并打开](左)
    		name: "baidu搜索选中文字(后台)[识别URL和空格并打开]",
    		cmd: function(event) {
    			(seemAsURL(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"").replace(/^[hх]..[pп]:\/\//i,"http://").replace(/^[fф].[pп]:\/\//i,"ftp://").replace(/^ftp\./i,"ftp://ftp.")) && gBrowser.addTab(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"").replace(/^[hх]..[pп]:\/\//i,"http://").replace(/^[fф].[pп]:\/\//i,"ftp://").replace(/^ftp\./i,"ftp://ftp."))) || gBrowser.addTab('https://www.baidu.com/s?wd=' + encodeURIComponent(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"")));
    	    }
    	},
        R: {
    		//Google搜索选中文字(后台)[识别URL和空格并打开](右)
    		name: "Google搜索选中文字(后台)[识别URL和空格并打开]",
    		cmd: function(event) {
                         (seemAsURL(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"").replace(/^[hх]..[pп]:\/\//i,"http://").replace(/^[fф].[pп]:\/\//i,"ftp://").replace(/^ftp\./i,"ftp://ftp.")) && gBrowser.addTab(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"").replace(/^[hх]..[pп]:\/\//i,"http://").replace(/^[fф].[pп]:\/\//i,"ftp://").replace(/^ftp\./i,"ftp://ftp."))) || gBrowser.addTab('http://www.google.com/search?q=' + encodeURIComponent(event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"")));
    		}
    	},
    	DL: {
    		//打开查找栏搜索文本(下-左)
    		name: "打开查找栏搜索文本",
    		cmd: function(event) {
    			gFindBar._findField.value = event.dataTransfer.getData("text/unicode").replace(/\s+/g,"").replace(/[(\r\n)|\r|\n]+/g,"").replace(/^[_(]|[,.)]$/g,"");
    			gFindBar.open();
    			gFindBar.toggleHighlight(1);
    		}
    	},
    	DR: {
    		//Google翻译文本（下-右）
    		name: "Google 翻译文本",
            cmd: function(event) {
                    var div = content.document.documentElement.appendChild(content.document.createElement("div"));
                    div.style.cssText = "position:absolute;z-index:1000;border:solid 2px rgb(144,144,144);border-radius:5px;background:-moz-linear-gradient(top, rgb(252, 252, 252) 0%, rgb(245, 245, 245) 33%, rgb(245, 245, 245) 100%);padding: 0px 3px 1px 3px;font-size: 12pt;color: rgb(66,66,66);left:" + +(event.clientX + content.scrollX + 10) + 'px;top:' + +(event.clientY + content.scrollY + 10) + "px";
                    var xmlhttp = new XMLHttpRequest;
                    xmlhttp.open("get", "http://translate.google.cn/translate_a/t?client=t&hl=zh-CN&sl=auto&tl=zh-CN&text=" + event.dataTransfer.getData("text/unicode"), 0);
                    xmlhttp.send();
                    goDoCommand("cmd_cut");/* 剪下选取文字 */
                    for(var i = 0; i < xmlhttp.responseText.length; i++) {
                    div.textContent += eval("(" + xmlhttp.responseText + ")")[0][i][0];
                    content.addEventListener("click", function(e) {
                            if (e.button==0) {
                            Components.classes['@mozilla.org/widget/clipboardhelper;1'].createInstance(Components.interfaces.nsIClipboardHelper).copyString(div.textContent);/* 复制翻译结果 */
                            goDoCommand("cmd_paste");/* 贴上翻译结果 */
                            }
    		        else if (e.button==2) {
    			        e.preventDefault();
                            }
                            content.removeEventListener("click", arguments.callee, false);
                            div.parentNode.removeChild(div);
                    }, false);
                };
            }
        },
    },
}	