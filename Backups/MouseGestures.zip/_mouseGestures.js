GESTURES = {
	//侧栏打开谷歌翻译(按住左键点右键)
	    "L>R" : {
	    	name: "侧栏打开谷歌翻译",
	    	cmd: function() {
	            var sidebarBox = document.getElementById("sidebar-box");
                    if (sidebarBox.hidden) {
                        openWebPanel("谷歌翻译","http://translate.google.com/m/translate");
                    } else {
                        toggleSidebar("viewWebPanelsSidebar");
                }
	    	}    
	    },	
	    //侧栏打开豆瓣电台(按住右键点左键)
	    "L<R" : {
	        name: "侧栏打开豆瓣电台",
	    	cmd: function() {
	            var sidebarBox = document.getElementById("sidebar-box");
                    if (sidebarBox.hidden) {
                        openWebPanel("豆瓣电台","http://douban.fm/partner/sidebar");
                    } else {
                        toggleSidebar("viewWebPanelsSidebar");
                }
	    	}    
	    },	
/*		//刷新当前页面(上)
	    "U" : {
	    	name : "刷新当前页面",
	    	cmd : function () {
	    		gBrowser.mCurrentBrowser.reload();
	    	}
	    },
		//停止载入当前页(下)
	    "D": {
	    	name: "停止载入当前页",
	    	cmd: function() {
	    		BrowserStop();
	    	}
	    },*/
	    //转到页首(上)
	    "U" : {
	    	name : "转到页首",
	    	cmd : function () {
			    goDoCommand("cmd_scrollTop");
	    	}
	    },
	    //转到页尾(下)
	    "D" : {
	    	name : "转到页尾",
	    	cmd : function () {
			    goDoCommand("cmd_scrollBottom");
	    	}
	    },
	    // 增强型后退,没后退翻到上一页(左)
       "L" : {
            name : "增强型后退,没后退翻到上一页",
            cmd : function () {
                    var nav = gBrowser.webNavigation;
                    if (nav.canGoBack) {
                        nav.goBack();
                    } else {
                    var document = window.content.document;
                    var links = document.links;
                    for(i = 0; i < links.length; i++) {
                    if ((links[i].text == '上一頁') || (links[i].text == '上一页') || (links[i].text == '上一章') || (links[i].text == '上一张') || (links[i].text == '上一节') || (links[i].text == '上一幅') || (links[i].text == '上一篇') || (links[i].text == '上篇') || (links[i].text == '前一页') || (links[i].text == '<上一页') || (links[i].text == '« 上一页') || (links[i].text == '<<上一页') || (links[i].text == '[上一页]') || (links[i].text == '翻上页') || (links[i].text == '【上一页】') || (links[i].text == 'Prev') || (links[i].text == 'Previous') || (links[i].text == 'previous Page') || (links[i].text == '后退') || (links[i].text == '後退') || (links[i].text == '前へ') || (links[i].text == '前のページ') ||(links[i].text == '«') || (links[i].text == '‹‹') || (links[i].text == '<')) document.location = links[i].href;
                    }
                }
            }
        },
       //增强型前进,没前进翻到下一页(右)
       "R" : {
            name : "增强型前进,没前进翻到下一页",
            cmd : function () {
                    var nav = gBrowser.webNavigation;
                    if (nav.canGoForward) {
                        nav.goForward();
                    } else {
                    var document = window.content.document;
                    var links = document.links;
                    for(i = 0; i < links.length; i++) {
                    if ((links[i].text == '下一頁') || (links[i].text == '下一页') || (links[i].text == '下一章') || (links[i].text == '下一张') || (links[i].text == '下一节') || (links[i].text == '下一幅') || (links[i].text == '下一篇') || (links[i].text == '下篇') || (links[i].text == '后一页') || (links[i].text == '>下一页') || (links[i].text == '下一页>') || (links[i].text == '下一页 »') || (links[i].text == '下一页>>') || (links[i].text == '[下一页]') || (links[i].text == '翻下页') || (links[i].text == '【下一页】') || (links[i].text == 'next') || (links[i].text == 'Next') || (links[i].text == 'Next Page') || (links[i].text == '前进') || (links[i].text == '后页') || (links[i].text == '往后') || (links[i].text == '次へ') || (links[i].text == '次のページ') || (links[i].text == '»') || (links[i].text == '››') || (links[i].text == '>')) document.location = links[i].href;
                    }
                }
            }
        },
	    //恢复关闭的标签页(左-右)
	    "LR": {
	    	name: "恢复关闭的标签页",
	    	cmd: function() {
	    		undoCloseTab();
	    	}
	    },
	    //关闭当前标签(右-左)
	    "RL": {
	    	name: "关闭当前标签",
	    	cmd: function() {
	    		gBrowser.removeCurrentTab();
	    	}
	    },
		//粘贴并搜索(上-下)
		//自行判断剪贴板内容是链接还是文本，链接粘贴到地址栏并打开，文本则粘贴调用当前搜索引擎搜索
		"UD": {
			name: "粘贴并搜索",
			cmd: function() {
                var str = readFromClipboard();
                    if(!str) return;
                    if (/^file:\/{3}|^data:.+|^(?!java script:)\S*?(([\w-]\.)+\w{2,7}|localhost([:\/]|$))\S*$/.test(str)) {
                        gBrowser.loadOneTab(str);
                    }
                    else{
                        BrowserSearch.loadSearch(str, true);   
                }
	    	}
	    },
		//用IE打开当前页(上-下-上)
		"UDU": {
			name: "用IE打开当前页",
	    	cmd: function() {
	    		try {
	    			var file = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties).get("ProgF", Components.interfaces.nsILocalFile);
	    			file.append("Internet Explorer");
	    			file.append("iexplore.exe");
	    			var process = Cc["@mozilla.org/process/util;1"].createInstance(Ci.nsIProcess);
	    			process.init(file);
	    			process.run(false, [content.location.href], 1);
	    		} catch (ex) {
	    			alert("打开IE失败!")
	    		}
	    	}
	    },
		//页面编码GB互转UTF8(下-上-下)
		"DUD": {
	    	name: "页面编码GB互转UTF8",
	    	cmd: function() {
	    		var charset = gBrowser.mCurrentBrowser._docShell.charset;
                BrowserSetForcedCharacterSet(charset == "UTF-8" ? "GBK" : "UTF-8");
	    	}
	    },
	    //删除启动缓存并重启(下-上)
	    "DU": {
	    	name: "删除启动缓存并重启",
	    	cmd: function() {
	    		Services.appinfo.invalidateCachesOnRestart() || Application.restart();
	    	}
	    },
        //打开错误控制台窗口(下-左)
	    "DL": {
		    name: "打开错误控制台窗口",
			cmd: function() {
				toJavaScriptConsole();
			}
	    },
	    //翻译当前页面(下-右)
		//有选择项优先翻译选择项，否则翻译整个网页(部分支持https)
	    "DR": {
	        name: "翻译当前页面",
	    	cmd: function() {
			    var t = content.getSelection().toString();
                    if(t) {
					gBrowser.selectedTab = gBrowser.addTab("http://translate.google.cn/translate_t?hl=zh-CN#auto|zh-CN|"+t);	
				} else {
					var LANG = 'zh-CN';
	    		    var docurl = content.location.href;
	    		    var prefix = 'http://translate.google.com/translate?sl=auto';
                    var isChanged = docurl.indexOf(prefix) !== -1;
                    if (docurl.match(/^about/)) {
                        return;
                    } else if(docurl.match(/^https/)) {
	                    docurl = docurl.replace(/https/i, "http");
                    }
	    		    var openUrl;
                        if (isChanged) {
                            openUrl = decodeURIComponent(docurl.match(/u=(.+?)$/)[1]);
                        } else {
                            openUrl = prefix + '&tl=' + LANG + '&u=' + encodeURIComponent(docurl);
                        }
//                      gBrowser.loadURI(openUrl);//当前页
                        gBrowser.addTab(openUrl);//新标签页（后台）
//	    		        gBrowser.selectedTab = gBrowser.addTab(openUrl);//新标签页（前台）
//				    	gBrowser.selectedTab = gBrowser.addTab("http://translate.google.cn/translate?u="+content.location);
			    }
	    	}
	    },
	    //打开Profile目录(右-下)
	    "RD": {
	    	name: "打开Profile目录",
	    	cmd: function() {
	    		Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties).get("ProfD", Components.interfaces.nsILocalFile).reveal();
	    	}
	    },
	    //打开about:config(左-下)
	    "LD": {
	    	name: "打开about:config",
	    	cmd: function() {
	    		gBrowser.selectedTab = gBrowser.addTab("about:config");
	    	}
	    },
	    //打开我的足迹窗口(左-上)
	    "LU": {
	    	name: "打开我的足迹窗口",
	    	cmd: function() {
	    		PlacesCommandHook.showPlacesOrganizer('History');
	    	}
	    },
	    //切换代理(无代理<->手动配置代理)(右-上)
	    "RU": {
	    	name: "切换代理(无代理<->手动配置代理)",
	    	cmd: function() {
	    		var pref = Components.classes["@mozilla.org/preferences-service;1"].getService(Components.interfaces.nsIPrefService);
	    		pref.setIntPref("network.proxy.type", pref.getIntPref("network.proxy.type") == 0 ? 1 : 0);
	    	}
	    },
		//飞驴视频解析下载(上-左)
	    "UL": {
	    	name: "flvxz视频解析下载",
	    	cmd: function() {
	    		gBrowser.addTab('http://flvxz.com/?url='+ encodeURIComponent(content.location.href) + '&flag=&format=high');
	    	}	
	    },
	    //Flvcd视频解析下载(上-右)
	    "UR": {
	    	name: "Flvcd视频解析下载",
	    	cmd: function() {
	    		gBrowser.addTab('http://www.flvcd.com/parse.php?kw='+ encodeURIComponent(content.location.href) + '&flag=&format=high');
	    	}	
	    },
		//跳过缓存刷新当前页面(上-左-下)(∩)
	    "ULD": {
	    	name: "跳过缓存刷新当前页面",
	    	cmd: function() {
	    		BrowserReloadSkipCache();
	    	}
	    },
		//保存所有图片到 zip(下-左-上)(U)
		"DLU": {
			name: "保存所有图片到 zip",
			cmd: function() {
			    // 保存ディレクトリのパスがない场合は毎回ダイアログで决める
                //var path = "C:\\Users\\azu\\Downloads"; // エスケープしたディレクトリのパス
                var path = "";
                        if (!path) {
                            // ファイル保存ダイアログ
                            var nsIFilePicker = Ci.nsIFilePicker;
                            var FP = Cc['@mozilla.org/filepicker;1'].createInstance(nsIFilePicker);
                            FP.init(window, 'Choose save folder.', nsIFilePicker.modeGetFolder);
                        
                            // ダイアログ表示
                            if (FP.show() == nsIFilePicker.returnOK) {
                                path = FP.file.path;
                            } else {
                                return false;
                            }
                        }
                        // ダウンロードしたページを表示するために URI オブジェクト生成
                        var hostURL = Components.classes['@mozilla.org/network/io-service;1'].getService(Components.interfaces.nsIIOService).newURI(location.href, null, null);
                        // ページに贴り付けられた画像を保存する
                        var links = content.document.images;
                        var pack = [];
                        for (var i = 0, length = links.length; i < length; i++) {
                            // JPEG と PNG を保存する
                            if (links[i].src.match(/\.jpe?g|\.png|img\.blogs\.yahoo(.*)folder[^thumb]/i)) {
                                pack.push([links[i].src.split("/").pop(), links[i].src]);
                            }
                        }
                        zipDeKure(pack, path);
                  
                  
                        function zipDeKure(urls, savePath) {
                            const ioService = Cc["@mozilla.org/network/io-service;1"].getService(Ci.nsIIOService);
                            const zipWriter = Components.Constructor("@mozilla.org/zipwriter;1", "nsIZipWriter");
                            var uri = content.window.location.href;
                            var fileName = uri.substring(uri.lastIndexOf('://') + 3, uri.length);
                            fileName = fileName.split(".").join("_");
                            fileName = fileName.split("/").join("_");
                            fileName = fileName.split("?").join("_");
                            var path = savePath + "\\" + fileName + ".zip";
                            var file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
                            file.initWithPath(path);
                            var zipW = new zipWriter();
                            var ioFlag = 0x04 | 0x08 | 0x20;
                            zipW.open(file, ioFlag);
                            for (var i = 0, len = urls.length; i < len; i++) {
                                var [name, url] = urls[i];
                                var ch = ioService.newChannel(url, "UTF-8", null);
                                var stream = ch.open();
                                zipW.addEntryStream(name, Date.now() * 1000, Ci.nsIZipWriter.COMPRESS_DEFAULT, stream, false);
                            }
                            zipW.close();
                        }
/*				Array.map(gBrowser.browsers, function(browser) {
					browser.stop()
				});*/
			}
		},
		//打开选项窗口(上-右-下)(∩)
	    "URD": {
	    	name: "打开选项窗口",
			cmd: function() { 
				openPreferences();
			}
	    },
		//打开附加组件窗口(下-右-上)(U)
		"DRU": {
			name: "打开附加组件窗口",
			cmd: function() {
				BrowserOpenAddonsMgr();
			}
		},
		//添加到书签(右-下-左)(ɔ)
		"RDL": {
			name: "添加到书签",
	    	cmd: function() {
	    		PlacesCommandHook.bookmarkCurrentPage(true, PlacesUtils.bookmarksMenuFolderId);
	    	}
		},
		//清理浏览痕迹(左-下-右)(C)
    	"LDR" : {
    		name : "清理浏览痕迹",
    		cmd : function () {
    			Cc['@mozilla.org/browser/browserglue;1'].getService(Ci.nsIBrowserGlue).sanitize(window);
    		}
		},
        //刷新当前页面(下-左-上-右)(O)
	    "DLUR" : {
	    	name : "刷新当前页面",
	    	cmd : function () {
	    		gBrowser.mCurrentBrowser.reload();
	    	}
	    },
		//刷新当前页面(右-下-左-上-右)(容易误识别,采用多重设置)
	    "RDLUR" : {
	    	name : "刷新当前页面",
	    	cmd : function () {
	    		gBrowser.mCurrentBrowser.reload();
	    	}
	    },	
		//刷新当前页面(下-右-上-左)(O)
	    "DRUL" : {
	    	name : "刷新当前页面",
	    	cmd : function () {
	    		gBrowser.mCurrentBrowser.reload();
	    	}
	    },
		//刷新当前页面(左-下-右-上-左)(容易误识别,采用多重设置)
	    "LDRUL" : {
	    	name : "刷新当前页面",
	    	cmd : function () {
	    		gBrowser.mCurrentBrowser.reload();
	    	}
	    },
		//停止载入当前页(右-下-右)(Z)
		"RDR": {
	    	name: "停止载入当前页",
	    	cmd: function() {
	    		BrowserStop();
	    	}
	    },
		//停止载入当前页(右-左-右)(容易误识别,采用多重设置)
		"RLR": {
	    	name: "停止载入当前页",
	    	cmd: function() {
	    		BrowserStop();
	    	}
	    },
		//停止载入当前页(右-下-左-右)(容易误识别,采用多重设置)
		"RDLR": {
	    	name: "停止载入当前页",
	    	cmd: function() {
	    		BrowserStop();
	    	}
	    },
		//复制当前页面URL(下-左-下)
		"ULU": {
	    	name: "复制当前页面URL",
	    	cmd: function() {
			    Components.classes['@mozilla.org/widget/clipboardhelper;1'].getService(Components.interfaces.nsIClipboardHelper).copyString(content.location);
	    	}
	    },
		//保存当前页面(下-左-下)
		"URU": {
	    	name: "保存当前页面",
	    	cmd: function() {
			    saveDocument(window.content.document);
	    	}
	    },
		//浏览器界面截图(下-左-下)
		"DLD": {
	    	name: "浏览器界面截图",
	    	cmd: function() {
			    var canvas = document.createElementNS("http://www.w3.org/1999/xhtml", "canvas");
                    canvas.width = innerWidth;
                    canvas.height = innerHeight;
                var ctx = canvas.getContext("2d");
                    ctx.drawWindow(window, 0, 0, canvas.width, canvas.height, "rgb(255,255,255)");
                    saveImageURL(canvas.toDataURL(), content.document.title + ".png", null, null, null, null, document);
	    	}
	    },
		//保存当前站点图标(下-右-下)
		"DRD": {
	    	name: "保存当前站点图标",
	    	cmd: function() {
	    		saveURL(gBrowser.mCurrentTab.image, null, null, false, null, null, document);
	    	}
	    },
}